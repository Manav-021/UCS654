from setuptools import setup

setup(
    name="Topsis-Manavjot-102317270",
    version="1.0.0",
    packages=["topsis"],
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis.topsis:main"
        ]
    },
)
